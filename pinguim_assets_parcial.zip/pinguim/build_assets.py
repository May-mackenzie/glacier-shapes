#!/usr/bin/env python3
# Gera todos os assets (sprites, animações, tilesets, cenários, sons) do Pinguim Herói.
import os, json, math, random, wave, collections
import numpy as np
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
os.makedirs(OUT, exist_ok=True)
U = "/mnt/user-data/uploads/WhatsApp_Image_2026-10-28_at_"
META = {}


def save(img, name):
    img.save(os.path.join(OUT, name + ".png"))


def flood_bg(arr, thr=45):
    h, w, _ = arr.shape
    dark = arr.astype(int).sum(axis=2) < thr
    bg = np.zeros((h, w), bool)
    dq = collections.deque()
    for x in range(w):
        for y in (0, h - 1):
            if dark[y, x] and not bg[y, x]:
                bg[y, x] = True; dq.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if dark[y, x] and not bg[y, x]:
                bg[y, x] = True; dq.append((y, x))
    while dq:
        y, x = dq.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and dark[ny, nx] and not bg[ny, nx]:
                bg[ny, nx] = True; dq.append((ny, nx))
    return bg


def rgba_from(arr):
    bg = flood_bg(arr)
    a = np.where(bg, 0, 255).astype(np.uint8)
    return np.dstack([arr, a])


# ---------------------------------------------------------------- pinguim
pen_img = Image.open(U + "16_24_15.jpeg").convert("RGB").resize((38, 38), Image.NEAREST)
PB = rgba_from(np.array(pen_img))
save(Image.fromarray(PB, "RGBA"), "penguin_base")

R_, G_, B_, A_ = [PB[:, :, i].astype(int) for i in range(4)]
YY, XX = np.mgrid[0:38, 0:38]
scarf = (A_ > 0) & (R_ > 120) & (R_ - G_ > 45) & (G_ < 110) & (YY <= 30)
feetL = (A_ > 0) & (YY >= 34) & (XX <= 20)
feetR = (A_ > 0) & (YY >= 34) & (XX >= 25)
flipper = (A_ > 0) & (XX >= 33) & (YY >= 22) & (YY <= 30) & ~scarf
body_mask = (A_ > 0) & ~scarf & ~feetL & ~feetR & ~flipper
C = 48
OX, OY = 5, 9


def warp(mask, bob=0, sy=1.0, sx=1.0, lean=0.0, off=(0, 0)):
    out = np.zeros((C, C, 4), np.uint8)
    for yd in range(C):
        dy = yd - OY - off[1]
        sy_ = 34 + (dy - 34 - bob) / sy
        syi = int(math.floor(sy_ + 0.5))
        if not 0 <= syi < 38:
            continue
        for xd in range(C):
            dx = xd - OX - off[0]
            sx_ = 19 + (dx - 19 - lean * (34 - sy_) / 34.0) / sx
            sxi = int(math.floor(sx_ + 0.5))
            if 0 <= sxi < 38 and mask[syi, sxi]:
                out[yd, xd] = PB[syi, sxi]
    return out


def shift_mask(mask, dx, dy, bobx=0):
    out = np.zeros((C, C, 4), np.uint8)
    ys, xs = np.nonzero(mask)
    for y, x in zip(ys, xs):
        nx, ny = x + OX + dx, y + OY + dy
        if 0 <= nx < C and 0 <= ny < C:
            out[ny, nx] = PB[y, x]
    return out


def warp_scarf(bob, sy, lean, amp, ph, dy_, k):
    out = np.zeros((C, C, 4), np.uint8)
    for yd in range(C):
        for xd in range(C):
            dx = xd - OX - lean * 0.5
            dyy = yd - OY
            w = min(1.0, max(0.0, (22 - dx) / 12.0))
            oyy = w * (amp * math.sin(ph + dx * 0.45) + dy_)
            sy_ = 34 + (dyy - 34 - bob * 0.8 - oyy) / sy
            if dx < 22:
                sx_ = 22 - (22 - dx) / (1 + k * w)
            else:
                sx_ = dx
            syi = int(math.floor(sy_ + 0.5)); sxi = int(math.floor(sx_ + 0.5))
            if 0 <= syi < 38 and 0 <= sxi < 38 and scarf[syi, sxi]:
                out[yd, xd] = PB[syi, sxi]
    return out


def over(dst, src):
    m = src[:, :, 3] > 0
    dst[m] = src[m]
    return dst


def pose(bob=0, sy=1.0, sx=1.0, lean=0.0, amp=1.4, ph=0.0, sdy=0.0, sk=0.0,
         fl=(0, 0), fr=(0, 0), arm=(0, 0)):
    img = warp(body_mask, bob, sy, sx, lean)
    # pés ficam no chão (acompanham o corpo só no x)
    lx = int(round(lean * 0.0))
    over(img, shift_mask(feetL, fl[0], fl[1]))
    over(img, shift_mask(feetR, fr[0], fr[1]))
    over(img, warp(flipper, bob, sy, sx, lean, arm))
    over(img, warp_scarf(bob, sy, lean, amp, ph, sdy, sk))
    return img


def build_penguin():
    poses = collections.OrderedDict()
    poses["idle"] = [dict(sy=[1.0, 1.03, 1.06, 1.03][i], ph=i * 1.57, amp=1.3) for i in range(4)]
    run = []
    for i in range(6):
        p = 2 * math.pi * i / 6
        fl = (round(3 * math.sin(p)), -round(max(0, -math.cos(p)) * 3))
        fr = (round(3 * math.sin(p + math.pi)), -round(max(0, -math.cos(p + math.pi)) * 3))
        bob = -1 if abs(math.sin(p)) < 0.5 else 0
        run.append(dict(bob=bob, lean=3, sdy=-2, sk=0.25, amp=1.5, ph=i * 1.1, fl=fl, fr=fr,
                        arm=(0, round(1.5 * math.sin(p)))))
    poses["run"] = run
    poses["jump"] = [dict(sy=1.12, lean=1, sdy=3, amp=1, fl=(1, -3), fr=(-1, -2), arm=(1, -3)),
                     dict(sy=1.05, lean=1, sdy=1, amp=1.5, ph=1, fl=(1, -2), fr=(-1, -1), arm=(1, -2))]
    poses["fall"] = [dict(sy=0.96, sx=1.04, sdy=-3, amp=2, fl=(-3, -1), fr=(3, -1), arm=(1, -3)),
                     dict(sy=0.97, sx=1.04, sdy=-3, amp=2, ph=1.5, fl=(-3, -1), fr=(3, -1), arm=(1, -4))]
    poses["dash"] = [dict(sx=1.3, sy=0.82, lean=6, sk=0.4, sdy=-1, amp=0.5, fl=(-3, -2), fr=(-2, -2), arm=(-2, 0)),
                     dict(sx=1.34, sy=0.8, lean=7, sk=0.45, sdy=-1, amp=0.5, ph=1, fl=(-4, -2), fr=(-3, -2), arm=(-2, 0))]
    poses["land"] = [dict(sy=0.78, sx=1.12, fl=(-3, 0), fr=(3, 0), amp=1, sdy=-2),
                     dict(sy=0.9, sx=1.05, fl=(-2, 0), fr=(2, 0), amp=1)]
    poses["hurt"] = [dict(sy=1.08, lean=-4, sdy=-4, amp=2, fl=(-2, -1), fr=(2, -1), arm=(1, -6))]
    poses["attack1"] = [dict(lean=-3, sy=0.95, arm=(-1, -6), amp=1.5, sdy=-1),
                        dict(lean=6, sx=1.12, sy=0.95, arm=(5, -3), sk=0.4, sdy=-3, amp=1),
                        dict(lean=3, arm=(3, 0), sdy=-2, amp=1.2)]
    poses["attack2"] = [dict(lean=-2, sy=0.9, arm=(0, 4), amp=1.5, sdy=-1, fl=(-2, 0), fr=(2, 0)),
                        dict(lean=7, sx=1.1, sy=1.0, arm=(5, -7), sk=0.5, sdy=-3, amp=1, fl=(2, 0), fr=(4, 0)),
                        dict(lean=3, arm=(3, -2), sdy=-2, amp=1.2)]
    poses["attack3"] = [dict(lean=-4, sy=0.85, arm=(0, -6), fl=(-2, 0), fr=(2, 0), amp=1.5),
                        dict(sx=0.62, sy=1.04, arm=(-3, -4), amp=2, ph=1),
                        dict(sx=0.9, sy=1.1, arm=(4, -8), lean=4, amp=2, sdy=-3, fl=(-3, -2), fr=(3, -2)),
                        dict(sx=1.15, lean=7, arm=(6, -5), sk=0.5, sdy=-2, amp=1, fl=(-3, 0), fr=(3, 0))]
    poses["special"] = [dict(lean=-3, sy=1.06, arm=(0, -8), amp=2, ph=0.5, fl=(-2, 0), fr=(2, 0)),
                        dict(lean=6, sx=1.12, arm=(6, -5), sk=0.5, sdy=-3, amp=1, fl=(-3, 0), fr=(3, 0))]
    maxn = max(len(v) for v in poses.values())
    sheet = Image.new("RGBA", (C * maxn, C * len(poses)), (0, 0, 0, 0))
    meta = {}
    for row, (name, lst) in enumerate(poses.items()):
        meta[name] = [row, len(lst)]
        for i, kw in enumerate(lst):
            sheet.paste(Image.fromarray(pose(**kw), "RGBA"), (i * C, row * C))
    save(sheet, "penguin")
    META["penguin"] = dict(cell=[C, C], anims=meta, baseline=46)


build_penguin()

# ---------------------------------------------------------------- drone (inimigo da imagem)
en = Image.open(U + "16_24_45.jpeg").convert("RGB").resize((160, 40), Image.NEAREST)
ea = np.array(en)
sheet = Image.new("RGBA", (160, 40), (0, 0, 0, 0))
for i in range(4):
    fr = rgba_from(ea[:, i * 40:(i + 1) * 40].copy())
    sheet.paste(Image.fromarray(fr, "RGBA"), (i * 40, 0))
save(sheet, "drone")
META["drone"] = dict(cell=[40, 40], anims={"fly": [0, 4]})

# ---------------------------------------------------------------- utilidades de desenho
def newimg(w, h):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)


OUTL = (14, 18, 34, 255)


def sheet_from(frames, cw, ch):
    s = Image.new("RGBA", (cw * len(frames), ch), (0, 0, 0, 0))
    for i, f in enumerate(frames):
        s.paste(f, (i * cw, 0))
    return s


# ---------------------------------------------------------------- slime tóxico
def slime(w, h, eyeglow=0, cell=(32, 24)):
    im, d = newimg(*cell)
    cx = cell[0] // 2
    x0, x1 = cx - w // 2, cx + w // 2
    y1 = cell[1] - 1
    y0 = y1 - h
    d.ellipse([x0, y0, x1, y1 + h * 0.9], fill=(96, 214, 40, 255), outline=(20, 50, 28, 255))
    # corta o fundo para ficar achatado
    im.paste((0, 0, 0, 0), (0, y1 + 1, cell[0], cell[1] + 40))
    d = ImageDraw.Draw(im)
    d.line([(x0 + 2, y1), (x1 - 2, y1)], fill=(20, 50, 28, 255))
    d.line([(x0 + 3, y1 - 1), (x1 - 3, y1 - 1)], fill=(52, 150, 40, 255))
    d.line([(x0 + 3, y1 - 2), (x1 - 3, y1 - 2)], fill=(52, 150, 40, 255))
    d.ellipse([x0 + 4, y0 + 3, x0 + 8, y0 + 5], fill=(210, 255, 130, 255))
    d.point([(x0 + 9, y0 + 3)], fill=(255, 255, 255, 255))
    ey = y0 + max(5, h // 2 - 1)
    for ex, sgn in ((cx - 6, 1), (cx + 2, -1)):
        d.line([(ex, ey), (ex + 3, ey + sgn)], fill=(10, 20, 20, 255), width=2)
        d.rectangle([ex + 1, ey + 1, ex + 2, ey + 2], fill=(230, 50 + eyeglow, 70, 255))
    # gotas
    d.point([(x0 + 2, y1 + 0), (x1 - 4, y1 - 4)], fill=(190, 255, 100, 255))
    return im


save(sheet_from([slime(26, 16), slime(28, 13), slime(22, 21, 80), slime(30, 11, 120)], 32, 24), "slime")
META["slime"] = dict(cell=[32, 24], anims={"all": [0, 4]})


# ---------------------------------------------------------------- torreta
def turret(frame):
    im, d = newimg(32, 32)
    steel, steel_d, steel_l = (84, 96, 130, 255), (46, 54, 84, 255), (150, 168, 205, 255)
    d.polygon([(3, 31), (6, 22), (26, 22), (29, 31)], fill=steel, outline=OUTL)
    d.rectangle([5, 27, 27, 29], fill=(236, 190, 40, 255))
    for x in range(5, 28, 4):
        d.line([(x, 27), (x + 2, 29)], fill=OUTL)
    d.rectangle([4, 7, 15, 22], fill=(120, 232, 50, 255), outline=(200, 230, 250, 255))
    d.rectangle([5, 8, 6, 20], fill=(210, 255, 140, 255))
    d.rectangle([9, 14, 13, 20], fill=(60, 160, 40, 255))
    d.rectangle([4, 5, 15, 7], fill=steel_d, outline=OUTL)
    rec = -2 if frame == 2 else 0
    d.rectangle([14 + rec, 11, 28 + rec, 18], fill=steel, outline=OUTL)
    d.rectangle([14 + rec, 11, 28 + rec, 12], fill=steel_l)
    d.rectangle([27 + rec, 10, 30 + rec, 19], fill=steel_d, outline=OUTL)
    glow = {0: (60, 120, 50), 1: (170, 255, 90), 2: (255, 255, 255)}[frame]
    d.rectangle([29 + rec, 13, 30 + rec, 16], fill=glow + (255,))
    d.rectangle([16, 14, 19, 16], fill=(230, 50, 70, 255) if frame == 0 else (255, 120, 120, 255))
    d.rectangle([8, 22, 24, 23], fill=steel_d)
    return im


save(sheet_from([turret(0), turret(1), turret(2)], 32, 32), "turret")
META["turret"] = dict(cell=[32, 32], anims={"all": [0, 3]})


# ---------------------------------------------------------------- chefes (3 paletas)
BOSS_PAL = [
    dict(steel=(84, 100, 140), dark=(44, 54, 90), light=(150, 175, 215), accent=(236, 190, 40), eye=(240, 50, 70)),
    dict(steel=(98, 70, 140), dark=(52, 36, 88), light=(170, 140, 220), accent=(80, 230, 200), eye=(255, 90, 200)),
    dict(steel=(140, 70, 56), dark=(76, 36, 36), light=(220, 150, 110), accent=(255, 150, 40), eye=(255, 220, 60)),
]


def boss(pal, squash=0, lean=0, smoke=0, glow=0, stretch=0):
    W, H = 96, 88
    im, d = newimg(W, H)
    st, dk, lt, ac, ey = [tuple(pal[k]) + (255,) for k in ("steel", "dark", "light", "accent", "eye")]
    gy = H - 2
    # esteiras
    d.rounded_rectangle([8, gy - 16, 88, gy], radius=7, fill=dk, outline=OUTL)
    for x in range(16, 84, 12):
        d.ellipse([x - 4, gy - 12, x + 4, gy - 4], fill=st, outline=OUTL)
    top = gy - 16
    body_top = top - 40 + squash - stretch
    d.rectangle([14 + lean // 2, body_top, 82 + lean // 2, top + 2], fill=st, outline=OUTL)
    d.rectangle([15 + lean // 2, body_top + 1, 81 + lean // 2, body_top + 4], fill=lt)
    for x in range(20, 80, 12):
        d.point([(x + lean // 2, body_top + 8), (x + lean // 2, top - 4)], fill=lt)
    d.rectangle([14 + lean // 2, top - 12, 82 + lean // 2, top - 6], fill=ac, outline=OUTL)
    for x in range(14, 82, 8):
        d.line([(x + lean // 2, top - 12), (x + 4 + lean // 2, top - 6)], fill=OUTL)
    # cabeça / visor
    hx = 26 + lean
    hy = body_top - 22
    d.rectangle([hx, hy, hx + 44, hy + 26], fill=dk, outline=OUTL)
    d.rectangle([hx + 4, hy + 4, hx + 40, hy + 22], fill=(190, 210, 235, 255), outline=OUTL)
    d.rectangle([hx + 6, hy + 6, hx + 38, hy + 20], fill=(26, 30, 48, 255))
    ec = tuple(min(255, c + glow) for c in pal["eye"]) + (255,)
    for ex, s in ((hx + 10, 1), (hx + 24, -1)):
        d.line([(ex, hy + 10), (ex + 8, hy + 10 + 3 * s)], fill=ec, width=3)
        d.line([(ex, hy + 11), (ex + 8, hy + 11 + 3 * s)], fill=ec, width=2)
    d.rectangle([hx + 6, hy + 6, hx + 10, hy + 7], fill=(230, 240, 255, 255))
    # chaminé
    cx = 66 + lean
    d.rectangle([cx, hy - 14, cx + 12, hy + 4], fill=st, outline=OUTL)
    d.rectangle([cx - 2, hy - 18, cx + 14, hy - 13], fill=dk, outline=OUTL)
    for i, (sx_, sy_, r) in enumerate([(cx + 6, hy - 26, 5), (cx + 12, hy - 36, 6), (cx + 4, hy - 46, 7)]):
        o = int(smoke * 3) % 6
        if sy_ - o > 0:
            d.ellipse([sx_ - r, sy_ - o - r, sx_ + r, sy_ - o + r], fill=(70, 60, 80, 255), outline=(40, 34, 50, 255))
    # tanque lateral
    d.rectangle([2, body_top + 6, 16, top - 2], fill=(120, 232, 50, 255), outline=(200, 230, 250, 255))
    d.rectangle([4, body_top + 8, 6, top - 6], fill=(210, 255, 140, 255))
    d.rectangle([16, body_top + 20, 22, body_top + 26], fill=dk, outline=OUTL)
    # garra
    d.rectangle([82 + lean // 2, body_top + 12, 92 + lean // 2, body_top + 22], fill=dk, outline=OUTL)
    d.polygon([(92 + lean // 2, body_top + 10), (95, body_top + 16), (92 + lean // 2, body_top + 24)], fill=lt, outline=OUTL)
    return im


boss_meta = {}
for bi, pal in enumerate(BOSS_PAL):
    frs = [boss(pal), boss(pal, smoke=1.5), boss(pal, squash=8, glow=60), boss(pal, stretch=6, smoke=2),
           boss(pal, lean=6, glow=40, smoke=1)]
    save(sheet_from(frs, 96, 88), "boss%d" % (bi + 1))
META["boss"] = dict(cell=[96, 88], anims={"idle": [0, 2], "wind": [2, 1], "air": [3, 1], "charge": [4, 1]})


# ---------------------------------------------------------------- projéteis, itens, efeitos
def ball(r):
    im, d = newimg(24, 24)
    c = 12
    d.ellipse([c - r, c - r, c + r, c + r], fill=(120, 235, 50, 255), outline=(24, 70, 30, 255))
    d.ellipse([c - r + 2, c - r + 2, c - r + 4, c - r + 4], fill=(230, 255, 160, 255))
    d.ellipse([c, c, c + r - 2, c + r - 2], fill=(60, 170, 40, 255))
    return im


def drop(l):
    im, d = newimg(24, 24)
    d.polygon([(12, 12 - l), (8, 12), (12, 18), (16, 12)], fill=(120, 235, 50, 255), outline=(24, 70, 30, 255))
    d.point([(10, 12)], fill=(230, 255, 160, 255))
    return im


def wave_fx(k):
    im, d = newimg(24, 24)
    h = [10, 16, 12][k]
    d.polygon([(2, 23), (12, 23 - h), (22, 23)], fill=(120, 235, 50, 255), outline=(24, 70, 30, 255))
    d.polygon([(8, 23), (12, 23 - h + 5), (16, 23)], fill=(210, 255, 120, 255))
    return im


save(sheet_from([ball(5), ball(6), ball(5), drop(6), drop(4), wave_fx(0), wave_fx(1), wave_fx(2)], 24, 24), "proj")
META["proj"] = dict(cell=[24, 24], anims={"ball": [0, 3], "drop": [3, 2], "wave": [5, 3]})


def icebolt(k):
    im, d = newimg(48, 24)
    d.polygon([(2, 12), (14, 4), (44, 11), (44, 13), (14, 20)], fill=(150, 215, 255, 255), outline=(40, 90, 170, 255))
    d.polygon([(10, 12), (16, 8), (42, 12), (16, 15)], fill=(235, 250, 255, 255))
    d.line([(6 + k * 4, 12), (36, 12)], fill=(255, 255, 255, 255))
    for i in range(3):
        d.point([(2 + i * 3 + k, 6 + i * 6)], fill=(200, 240, 255, 255))
    return im


save(sheet_from([icebolt(0), icebolt(1), icebolt(2)], 48, 24), "icebolt")


def fish(col, k):
    im, d = newimg(24, 16)
    body, belly, dark = col
    d.ellipse([2, 3, 16, 13], fill=body + (255,), outline=dark + (255,))
    d.polygon([(15, 8), (22, 2), (22, 14)], fill=body + (255,), outline=dark + (255,))
    d.ellipse([5, 8, 14, 12], fill=belly + (255,))
    d.rectangle([5, 6, 6, 7], fill=(255, 255, 255, 255))
    d.point([(6, 7)], fill=(0, 0, 0, 255))
    if k:
        d.point([(18, 2), (4, 2), (20, 12)], fill=(255, 255, 255, 255))
        d.line([(10, 0), (10, 2)], fill=(255, 255, 255, 255))
    return im


save(sheet_from([fish(((255, 170, 50), (255, 235, 150), (140, 70, 20)), 0), fish(((255, 170, 50), (255, 235, 150), (140, 70, 20)), 1)], 24, 16), "fish_gold")
save(sheet_from([fish(((70, 190, 255), (190, 240, 255), (20, 70, 140)), 0), fish(((70, 190, 255), (190, 240, 255), (20, 70, 140)), 1)], 24, 16), "fish_blue")


def crystal(k):
    im, d = newimg(40, 48)
    d.polygon([(20, 2), (32, 18), (26, 44), (14, 44), (8, 18)], fill=(120, 205, 255, 255), outline=(30, 70, 150, 255))
    d.polygon([(20, 2), (20, 44), (14, 44), (8, 18)], fill=(190, 235, 255, 255))
    d.polygon([(20, 8), (24, 18), (20, 36), (16, 18)], fill=(245, 255, 255, 255))
    for i, (x, y) in enumerate([(4, 10), (35, 20), (10, 40), (32, 6)]):
        if (i + k) % 4 < 2:
            d.line([(x - 2, y), (x + 2, y)], fill=(255, 255, 255, 255))
            d.line([(x, y - 2), (x, y + 2)], fill=(255, 255, 255, 255))
    return im


save(sheet_from([crystal(i) for i in range(4)], 40, 48), "crystal")


def barrel():
    im, d = newimg(16, 22)
    d.rectangle([1, 1, 14, 20], fill=(70, 80, 100, 255), outline=OUTL)
    d.rectangle([2, 2, 4, 19], fill=(110, 124, 150, 255))
    d.rectangle([1, 6, 14, 8], fill=(236, 190, 40, 255))
    d.rectangle([1, 14, 14, 16], fill=(236, 190, 40, 255))
    d.ellipse([5, 8, 10, 13], fill=(120, 232, 50, 255), outline=OUTL)
    d.point([(7, 10)], fill=(20, 40, 20, 255))
    return im


save(barrel(), "barrel")


def crescent(cell, center, r_in, r_out, a0, a1, upto, rev=False, shrink=0, dither=0.0, seed=0):
    rng = random.Random(seed)
    w, h = cell
    arr = np.zeros((h, w, 4), np.uint8)
    half = (a1 - a0) / 2.0
    mid = (a0 + a1) / 2.0
    for y in range(h):
        for x in range(w):
            dx, dy = x - center[0], y - center[1]
            r = math.hypot(dx, dy)
            ang = math.degrees(math.atan2(dy, dx))
            if not (a0 <= ang <= a1):
                continue
            frac = (ang - a0) / (a1 - a0)
            if rev:
                frac = 1 - frac
            if frac > upto:
                continue
            t = abs(ang - mid) / half
            ri = r_in + (r_out - r_in) * (t ** 1.4)
            ro = r_out - shrink
            if ri <= r <= ro:
                if dither and rng.random() < dither:
                    continue
                th = ro - ri
                p = (r - ri) / max(1, th)
                col = (150, 225, 255) if p > 0.75 or p < 0.12 else ((255, 255, 255) if 0.3 < p < 0.7 else (200, 240, 255))
                arr[y, x] = col + (255,)
    return Image.fromarray(arr, "RGBA")


def ring(cell, r, th, dither=0.0, seed=0):
    rng = random.Random(seed)
    w, h = cell
    arr = np.zeros((h, w, 4), np.uint8)
    cx, cy = w // 2, h // 2
    for y in range(h):
        for x in range(w):
            rr = math.hypot(x - cx, (y - cy) * 1.1)
            if r - th <= rr <= r:
                if dither and rng.random() < dither:
                    continue
                p = (rr - (r - th)) / th
                col = (150, 225, 255) if p > 0.7 or p < 0.2 else (255, 255, 255)
                arr[y, x] = col + (255,)
    return Image.fromarray(arr, "RGBA")


CELL = (72, 64)
fx = []
for rev in (False, True):
    for i, up in enumerate((0.5, 1.0, 1.0)):
        fx.append(crescent(CELL, (8, 32), 22, 40, -75, 75, up, rev=rev, shrink=[0, 0, 5][i],
                           dither=[0, 0, 0.35][i], seed=i))
for i, (r, th, dt) in enumerate([(14, 6, 0), (24, 7, 0), (33, 7, 0.1), (36, 5, 0.5)]):
    fx.append(ring(CELL, r, th, dt, seed=i))
save(sheet_from(fx, 72, 64), "slash")
META["slash"] = dict(cell=[72, 64], anims={"s1": [0, 3], "s2": [3, 3], "s3": [6, 4]})

# ---------------------------------------------------------------- tilesets
THEMES = {
    "dusk": dict(rock_dark=(20, 24, 52), rock_mid=(36, 44, 86), rock_light=(64, 78, 136), rock_out=(10, 12, 32),
                 snow_hi=(248, 252, 255), snow_mid=(190, 218, 248), snow_lo=(120, 150, 215)),
    "aurora": dict(rock_dark=(16, 18, 56), rock_mid=(32, 40, 98), rock_light=(60, 96, 156), rock_out=(8, 10, 34),
                   snow_hi=(230, 255, 252), snow_mid=(150, 228, 238), snow_lo=(70, 150, 205)),
    "melt": dict(rock_dark=(34, 22, 36), rock_mid=(62, 42, 56), rock_light=(106, 74, 82), rock_out=(18, 10, 20),
                 snow_hi=(232, 222, 230), snow_mid=(170, 154, 182), snow_lo=(106, 88, 124)),
}


def rock_tile(pal, seed):
    rng = random.Random(seed)
    big = Image.new("RGBA", (48, 48), pal["rock_dark"] + (255,))
    d = ImageDraw.Draw(big)
    stones = []
    for _ in range(4):
        stones.append((rng.randint(1, 14), rng.randint(1, 14), rng.randint(4, 6)))
    for ox in (-16, 0, 16):
        for oy in (-16, 0, 16):
            for (sx, sy, r) in stones:
                cx, cy = 16 + sx + ox, 16 + sy + oy
                d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=pal["rock_mid"] + (255,), outline=pal["rock_out"] + (255,))
                d.ellipse([cx - r + 1, cy - r + 1, cx - 1, cy - 1], fill=pal["rock_light"] + (255,))
                d.ellipse([cx - r + 3, cy - r + 3, cx + r - 2, cy + r - 2], fill=pal["rock_mid"] + (255,))
    return big.crop((16, 16, 32, 32))


def snow_cap(base, pal, seed):
    rng = random.Random(seed)
    im = base.copy()
    d = ImageDraw.Draw(im)
    ph = rng.random() * 6.28
    heights = []
    for x in range(16):
        h = 5 + int(round(1.4 * math.sin(2 * math.pi * x / 16 + ph)))
        heights.append(h)
        for y in range(h):
            col = pal["snow_hi"] if y < h - 2 else (pal["snow_mid"] if y < h - 1 else pal["snow_lo"])
            if y == 0:
                col = pal["snow_hi"]
            d.point([(x, y)], fill=col + (255,))
    cols = rng.sample(range(0, 15), 5)
    for cx in cols:
        L = rng.randint(3, 8)
        w = rng.choice([2, 3])
        for k in range(L):
            ww = max(1, w - k // 3)
            for xx in range(ww):
                if cx + xx < 16:
                    col = pal["snow_mid"] if xx == 0 else pal["snow_lo"]
                    if k == L - 1:
                        col = pal["snow_hi"]
                    d.point([(cx + xx, heights[min(15, cx + xx)] + k)], fill=col + (255,))
    return im


def plat_tile(pal, seed):
    rng = random.Random(seed)
    im, d = newimg(16, 16)
    wood, wd = (140, 84, 46), (84, 48, 30)
    d.rectangle([0, 2, 15, 7], fill=wood + (255,), outline=wd + (255,))
    d.line([(0, 4), (15, 4)], fill=(168, 108, 62, 255))
    d.line([(8, 2), (8, 7)], fill=wd + (255,))
    d.point([(2, 5), (13, 5)], fill=(200, 200, 215, 255))
    if seed % 2:
        for x in range(0, 16, 4):
            d.rectangle([x, 6, x + 1, 7], fill=(236, 190, 40, 255))
    d.rectangle([0, 0, 15, 1], fill=pal["snow_hi"] + (255,))
    d.point([(c, 2) for c in range(0, 16, 2)], fill=pal["snow_mid"] + (255,))
    for cx in rng.sample(range(1, 15), 3):
        L = rng.randint(2, 5)
        for k in range(L):
            d.point([(cx, 8 + k)], fill=(pal["snow_hi"] if k == L - 1 else pal["snow_mid"]) + (255,))
    return im


def goo_tile(k, top):
    im, d = newimg(16, 16)
    d.rectangle([0, 0, 15, 15], fill=(88, 205, 40, 255))
    for i in range(5):
        x = (i * 7 + k * 3) % 16
        y = (i * 5 + 3 + k * 2) % 14
        d.ellipse([x, y + 1, x + 3, y + 4], fill=(150, 245, 80, 255), outline=(52, 150, 40, 255))
    d.rectangle([0, 13, 15, 15], fill=(52, 150, 40, 255))
    if top:
        im2, d2 = newimg(16, 16)
        for x in range(16):
            y = 3 + int(round(1.5 * math.sin(2 * math.pi * x / 16 + k * 1.57)))
            d2.rectangle([x, y, x, 15], fill=(88, 205, 40, 255))
            d2.point([(x, y)], fill=(215, 255, 120, 255))
            d2.point([(x, y + 1)], fill=(150, 245, 80, 255))
        im2.alpha_composite(im.crop((0, 0, 16, 16)).point(lambda v: v) if False else Image.new("RGBA", (16, 16), (0, 0, 0, 0)))
        # mistura textura do corpo
        body = im.copy()
        mask = im2.split()[3]
        body.putalpha(mask)
        body.paste(im2, (0, 0), im2)
        for x in range(16):
            y = 3 + int(round(1.5 * math.sin(2 * math.pi * x / 16 + k * 1.57)))
            body.putpixel((x, y), (215, 255, 120, 255))
        return body
    return im


for tname, pal in THEMES.items():
    ts = Image.new("RGBA", (64, 16 * 6), (0, 0, 0, 0))
    for i in range(4):
        rt = rock_tile(pal, 100 + i)
        ts.paste(rt, (i * 16, 0))
        ts.paste(snow_cap(rt, pal, 200 + i), (i * 16, 16))
        ts.paste(plat_tile(pal, i), (i * 16, 32))
        ts.paste(goo_tile(i, False), (i * 16, 48))
        ts.paste(goo_tile(i, True), (i * 16, 64))
        dr = rock_tile(dict(pal, rock_mid=pal["rock_dark"], rock_light=pal["rock_mid"]), 300 + i)
        ts.paste(dr, (i * 16, 80))
    save(ts, "tiles_" + tname)
META["tiles"] = dict(rows=dict(rock=0, top=1, plat=2, goo=3, goo_top=4, deep=5))


# ---------------------------------------------------------------- árvores
def pine(h, w, snow, dark, mid):
    im, d = newimg(w, h)
    cx = w // 2
    d.rectangle([cx - 2, h - 8, cx + 1, h - 1], fill=(70, 44, 36, 255))
    tiers = max(3, h // 14)
    th = (h - 8) // tiers + 4
    for i in range(tiers):
        top = i * (h - 14) // tiers
        bw = int((w // 2 - 1) * (0.45 + 0.55 * (i + 1) / tiers))
        by = top + th
        d.polygon([(cx, top), (cx - bw, by), (cx + bw, by)], fill=dark + (255,), outline=OUTL)
        d.polygon([(cx, top + 2), (cx - bw + 3, by - 1), (cx, by - 1)], fill=mid + (255,))
        d.polygon([(cx, top), (cx - bw // 2, top + th // 2), (cx + bw // 2, top + th // 2)], fill=snow + (255,))
    return im


def deadtree(h, w):
    im, d = newimg(w, h)
    cx = w // 2
    d.rectangle([cx - 2, h // 3, cx + 1, h - 1], fill=(40, 26, 34, 255), outline=OUTL)
    for y, dx in [(h // 3, -10), (h // 2, 11), (h * 2 // 3, -8)]:
        d.line([(cx, y + 4), (cx + dx, y - 8)], fill=(40, 26, 34, 255), width=2)
    return im


for tname, (dk, md, sn) in {"dusk": ((18, 52, 84), (30, 84, 116), (214, 232, 252)),
                           "aurora": ((16, 40, 84), (24, 78, 118), (190, 250, 248))}.items():
    save(sheet_from([pine(40, 24, sn, dk, md), pine(60, 32, sn, dk, md), pine(80, 40, sn, dk, md)], 40, 80), "trees_" + tname)
save(sheet_from([deadtree(40, 24), deadtree(60, 32), deadtree(78, 40)], 40, 80), "trees_melt")

# ---------------------------------------------------------------- cenários
def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def grad(h, stops):
    col = np.zeros((h, 3), np.uint8)
    for y in range(h):
        t = y / (h - 1)
        for i in range(len(stops) - 1):
            t0, c0 = stops[i]; t1, c1 = stops[i + 1]
            if t0 <= t <= t1:
                col[y] = lerp(c0, c1, (t - t0) / max(1e-6, t1 - t0)); break
    return col


def ridge(P, base, amp, seed, ks=(1, 2, 3, 5, 8, 13)):
    rng = random.Random(seed)
    ph = [rng.random() * 6.28 for _ in ks]
    ys = np.zeros(P)
    for i, k in enumerate(ks):
        a = amp / (1 + i * 0.9)
        ys += a * (1 - np.abs(np.sin(2 * np.pi * k * np.arange(P) / P + ph[i])))
    return base - ys


def mountains(P, H, base, amp, seed, c_lit, c_shade, c_cap, cap_line, c_bottom):
    arr = np.zeros((H, P, 4), np.uint8)
    ys = ridge(P, base, amp, seed)
    for x in range(P):
        y0 = int(ys[x]) // 2 * 2
        slope = ys[(x + 1) % P] - ys[x - 1]
        lit = slope > 0
        for y in range(max(0, y0), H):
            dep = y - y0
            if y0 < cap_line and dep < (cap_line - y0) * 0.9 + 3:
                col = c_cap if lit else lerp(c_cap, c_shade, 0.45)
            elif dep < 26:
                col = c_lit if lit else c_shade
            else:
                col = lerp(c_shade, c_bottom, min(1, (dep - 26) / 90))
            arr[y, x] = col + (255,)
    return Image.fromarray(arr, "RGBA")


def forest(P, H, base, seed, col, hi, hmin=26, hmax=64, step=10):
    im, d = newimg(P, H)
    rng = random.Random(seed)
    x = 0
    while x < P:
        h = rng.randint(hmin, hmax)
        w = h // 3 + 4
        for xo in (0, -P, P):
            cx = x + xo
            d.polygon([(cx, base - h), (cx - w, base), (cx + w, base)], fill=col + (255,))
            d.polygon([(cx, base - h), (cx - 2, base - h + 10), (cx + 2, base - h + 10)], fill=hi + (255,))
        x += rng.randint(step - 3, step + 5)
    d.rectangle([0, base, P, H], fill=col + (255,))
    return im


def stars(arr, n, seed, ymax):
    rng = random.Random(seed)
    for _ in range(n):
        x, y = rng.randrange(arr.shape[1]), rng.randrange(ymax)
        v = rng.choice([180, 220, 255])
        arr[y, x] = (v, v, 255)


def clouds(im, seed, cols, ymin, ymax, n):
    d = ImageDraw.Draw(im)
    rng = random.Random(seed)
    for _ in range(n):
        x, y = rng.randrange(im.width), rng.randrange(ymin, ymax)
        for i in range(rng.randint(3, 6)):
            r = rng.randint(7, 14)
            ox = i * rng.randint(8, 14)
            for j, c in enumerate(cols):
                d.ellipse([x + ox - r, y - r + j * 2, x + ox + r, y + r - 2 + j * 2], fill=c + (255,))


# ---- fase 1: imagem enviada
bg = Image.open(U + "16_21_39.jpeg").convert("RGB").resize((720, 405), Image.LANCZOS)
bg.save(os.path.join(OUT, "bg_stage1.png"))

# ---- fase 2: aurora noturna
def build_aurora():
    W, H = 704, 400
    sky = np.zeros((H, W, 3), np.uint8)
    g = grad(H, [(0, (6, 8, 34)), (0.45, (22, 24, 84)), (0.75, (58, 56, 142)), (1, (110, 96, 180))])
    sky[:] = g[:, None, :]
    stars(sky, 220, 5, 230)
    f = sky.astype(float)
    for k, (col, y0, amp) in enumerate([((70, 255, 170), 90, 26), ((120, 190, 255), 120, 20), ((190, 110, 255), 70, 18)]):
        for x in range(W):
            yc = y0 + amp * math.sin(x / 60.0 + k * 1.7) + 10 * math.sin(x / 23.0 + k)
            for y in range(int(yc) - 70, int(yc) + 6):
                if 0 <= y < H:
                    t = (y - (yc - 70)) / 76.0
                    a = (t ** 2.2) * (0.55 if (x // 3 + k) % 2 else 0.4)
                    f[y, x] = f[y, x] * (1 - a) + np.array(col) * a
    im = Image.fromarray(np.clip(f, 0, 255).astype(np.uint8), "RGB")
    d = ImageDraw.Draw(im)
    d.ellipse([500, 40, 548, 88], fill=(240, 244, 255), outline=(190, 205, 240))
    d.ellipse([514, 52, 522, 60], fill=(205, 214, 240)); d.ellipse([530, 66, 540, 76], fill=(205, 214, 240))
    d.ellipse([524, 46, 530, 52], fill=(205, 214, 240))
    im.save(os.path.join(OUT, "bg2_sky.png"))
    mountains(1280, 400, 250, 120, 11, (70, 82, 170), (34, 40, 100), (190, 215, 250), 170, (20, 24, 70)).save(os.path.join(OUT, "bg2_far.png"))
    mountains(1280, 400, 300, 90, 23, (50, 62, 140), (24, 28, 84), (150, 180, 235), 230, (14, 16, 54)).save(os.path.join(OUT, "bg2_near.png"))
    fo = forest(1280, 400, 340, 3, (10, 22, 56), (60, 110, 170))
    fo.save(os.path.join(OUT, "bg2_forest.png"))
    # lago com blocos de gelo
    im2, d2 = newimg(1280, 400)
    wg = grad(120, [(0, (40, 54, 130)), (1, (14, 18, 62))])
    for y in range(120):
        d2.line([(0, 290 + y), (1280, 290 + y)], fill=tuple(int(c) for c in wg[y]) + (255,))
    rng = random.Random(8)
    for _ in range(90):
        x, y = rng.randrange(1280), 296 + rng.randrange(100)
        d2.line([(x, y), (x + rng.randint(6, 24), y)], fill=(110, 150, 220, 255))
    for _ in range(18):
        x, y, w = rng.randrange(1280), 296 + rng.randrange(40), rng.randint(20, 46)
        d2.rectangle([x, y, x + w, y + 9], fill=(190, 225, 250, 255), outline=(90, 130, 210, 255))
        d2.rectangle([x, y, x + w, y + 2], fill=(245, 252, 255, 255))
    im2.save(os.path.join(OUT, "bg2_water.png"))


build_aurora()


# ---- fase 3: degelo / fábrica tóxica
def build_melt():
    W, H = 704, 400
    sky = np.zeros((H, W, 3), np.uint8)
    g = grad(H, [(0, (70, 14, 90)), (0.4, (170, 40, 90)), (0.7, (250, 110, 60)), (1, (255, 190, 90))])
    sky[:] = g[:, None, :]
    im = Image.fromarray(sky, "RGB").convert("RGBA")
    d = ImageDraw.Draw(im)
    d.ellipse([280, 150, 400, 270], fill=(255, 226, 120, 255), outline=(255, 190, 90, 255))
    d.ellipse([292, 162, 388, 258], fill=(255, 244, 170, 255))
    clouds(im, 4, [(86, 34, 84), (120, 48, 90)], 20, 200, 14)
    im.convert("RGB").save(os.path.join(OUT, "bg3_sky.png"))
    mountains(1280, 400, 256, 110, 31, (170, 70, 96), (88, 34, 76), (226, 150, 150), 190, (50, 20, 56)).save(os.path.join(OUT, "bg3_far.png"))
    mountains(1280, 400, 304, 80, 41, (110, 40, 70), (62, 24, 58), (176, 100, 110), 240, (36, 14, 44)).save(os.path.join(OUT, "bg3_near.png"))
    # skyline de fábricas
    sk, d3 = newimg(1280, 400)
    rng = random.Random(7)
    x = 0
    base = 344
    col = (34, 16, 40, 255)
    while x < 1280:
        w = rng.randint(30, 70); h = rng.randint(30, 90)
        d3.rectangle([x, base - h, x + w, base], fill=col)
        for wx in range(x + 5, x + w - 5, 9):
            for wy in range(base - h + 6, base - 6, 12):
                if rng.random() < 0.35:
                    d3.rectangle([wx, wy, wx + 3, wy + 4], fill=(255, 150, 50, 255))
        if rng.random() < 0.6:
            cx = x + rng.randint(6, max(7, w - 14))
            d3.rectangle([cx, base - h - 40, cx + 9, base - h], fill=col)
            d3.rectangle([cx - 1, base - h - 42, cx + 10, base - h - 38], fill=(54, 26, 58, 255))
            for i in range(3):
                r = 6 + i * 3
                d3.ellipse([cx + 4 - r + i * 4, base - h - 56 - i * 14 - r, cx + 4 + r + i * 4, base - h - 56 - i * 14 + r],
                           fill=(78, 48, 84, 255))
        x += w + rng.randint(2, 20)
    d3.rectangle([0, base, 1280, 400], fill=col)
    sk.save(os.path.join(OUT, "bg3_forest.png"))
    im2, d2 = newimg(1280, 400)
    wg = grad(120, [(0, (96, 220, 50)), (1, (24, 80, 40))])
    for y in range(120):
        d2.line([(0, 296 + y), (1280, 296 + y)], fill=tuple(int(c) for c in wg[y]) + (255,))
    for _ in range(100):
        x, y = rng.randrange(1280), 300 + rng.randrange(96)
        d2.line([(x, y), (x + rng.randint(6, 22), y)], fill=(190, 255, 110, 255))
    for _ in range(14):
        x, y, w = rng.randrange(1280), 300 + rng.randrange(40), rng.randint(14, 34)
        d2.rectangle([x, y, x + w, y + 8], fill=(190, 170, 200, 255), outline=(90, 70, 110, 255))
        d2.rectangle([x, y, x + w, y + 2], fill=(235, 225, 240, 255))
    im2.save(os.path.join(OUT, "bg3_water.png"))


build_melt()

# ---------------------------------------------------------------- sons
SR = 22050


def tone(f0, f1, dur, wav="square", vol=0.4, duty=0.5, decay=3.0):
    n = int(SR * dur)
    t = np.arange(n) / SR
    f = f0 + (f1 - f0) * (t / dur)
    ph = np.cumsum(f) / SR
    if wav == "square":
        s = np.where((ph % 1.0) < duty, 1.0, -1.0)
    elif wav == "saw":
        s = 2 * (ph % 1.0) - 1
    elif wav == "tri":
        s = 2 * np.abs(2 * (ph % 1.0) - 1) - 1
    else:
        s = np.sin(2 * np.pi * ph)
    env = np.exp(-decay * t / dur)
    return s * env * vol


def noise(dur, vol=0.4, decay=4.0, lp=1):
    n = int(SR * dur)
    rng = np.random.RandomState(int(dur * 1000))
    s = rng.uniform(-1, 1, n)
    if lp > 1:
        s = np.convolve(s, np.ones(lp) / lp, mode="same")
    t = np.arange(n) / SR
    return s * np.exp(-decay * t / dur) * vol


def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out


def seq(*parts):
    return np.concatenate(parts)


def wav_write(name, s):
    s = np.clip(s, -1, 1)
    data = (s * 32000).astype("<i2").tobytes()
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(data)


wav_write("jump", tone(260, 620, 0.13, "square", 0.3, 0.25))
wav_write("djump", tone(380, 900, 0.15, "square", 0.3, 0.125))
wav_write("dash", mix(noise(0.2, 0.5, 3, 6), tone(900, 200, 0.2, "saw", 0.2)))
wav_write("slash1", mix(noise(0.1, 0.45, 5, 3), tone(800, 300, 0.1, "square", 0.2, 0.25)))
wav_write("slash2", mix(noise(0.1, 0.45, 5, 3), tone(900, 380, 0.1, "square", 0.2, 0.25)))
wav_write("slash3", mix(noise(0.22, 0.6, 3, 5), tone(300, 1100, 0.22, "saw", 0.25)))
wav_write("hit", mix(noise(0.09, 0.6, 6, 2), tone(220, 70, 0.1, "square", 0.4)))
wav_write("kill", mix(noise(0.28, 0.55, 4, 4), tone(520, 80, 0.28, "square", 0.35, 0.25)))
wav_write("hurt", tone(380, 70, 0.32, "saw", 0.45))
wav_write("pickup", seq(tone(660, 660, 0.06, "square", 0.25, 0.25), tone(880, 880, 0.06, "square", 0.25, 0.25), tone(1180, 1180, 0.1, "square", 0.25, 0.25)))
wav_write("special", mix(noise(0.4, 0.4, 2, 8), tone(200, 1300, 0.4, "saw", 0.3, decay=1.5)))
wav_write("perfect", seq(tone(988, 988, 0.07, "sine", 0.5), tone(1318, 1318, 0.2, "sine", 0.5, decay=4)))
wav_write("boss_hit", mix(noise(0.12, 0.6, 5, 3), tone(150, 50, 0.16, "square", 0.5)))
wav_write("roar", mix(tone(110, 55, 0.7, "saw", 0.5, decay=1.5), noise(0.7, 0.3, 1.5, 12)))
wav_write("shock", mix(noise(0.35, 0.7, 3, 14), tone(90, 40, 0.35, "square", 0.4)))
wav_write("select", tone(880, 880, 0.05, "square", 0.25, 0.25))
wav_write("confirm", seq(tone(523, 523, 0.07, "square", 0.3, 0.25), tone(784, 784, 0.12, "square", 0.3, 0.25)))
wav_write("win", seq(*[tone(f, f, 0.14, "square", 0.3, 0.25) for f in (523, 659, 784, 1047, 784, 1047, 1318)]))
wav_write("lose", seq(*[tone(f, f, 0.22, "saw", 0.3) for f in (392, 330, 262, 196)]))
wav_write("shoot", mix(noise(0.12, 0.3, 4, 4), tone(500, 200, 0.12, "square", 0.2, 0.125)))


def music(name, bpm, root, scale, prog, seed, bars=8, lead_vol=0.13, bass_wave="square"):
    rng = random.Random(seed)
    step = 60.0 / bpm / 2
    n_steps = bars * 8
    total = int(SR * step * n_steps)
    out = np.zeros(total + SR)

    def put(arr, st, dur_steps, wavearr):
        i0 = int(SR * step * st)
        out[i0:i0 + len(wavearr)] += wavearr

    def hz(semi):
        return 440.0 * 2 ** ((semi - 9 + root) / 12.0)

    for b in range(bars):
        chord = prog[b % len(prog)]
        for s in range(8):
            st = b * 8 + s
            bn = chord + (0 if s % 4 != 3 else 12)
            if s % 2 == 0 or s in (3, 7):
                put(out, st, 1, tone(hz(bn - 12), hz(bn - 12), step * 0.9, bass_wave, 0.2, 0.5, 2.0))
            if rng.random() < 0.8:
                deg = rng.choice(scale)
                oct_ = rng.choice([0, 12, 12, 24])
                put(out, st, 1, tone(hz(chord + deg + oct_), hz(chord + deg + oct_), step * rng.choice([0.9, 1.8]), "square", lead_vol, 0.25, 3.0))
            if s % 4 == 0:
                put(out, st, 1, tone(160, 45, 0.14, "sine", 0.6, decay=5))
            if s % 4 == 2:
                put(out, st, 1, noise(0.12, 0.28, 6, 3))
            put(out, st, 1, noise(0.03, 0.08, 3, 1))
    out = out[:total]
    wav_write(name, out * 0.9)


minor = [0, 3, 7, 10, 12, 7, 3, 0, 5]
music("m1", 138, 0, minor, [0, -4, -9, -2], 1)
music("m2", 120, 2, [0, 3, 7, 10, 14, 7, 5], [0, -2, -7, -4], 2, lead_vol=0.11, bass_wave="tri")
music("m3", 150, 4, [0, 1, 7, 8, 12, 7, 3], [0, 1, 0, -2], 3)
music("mboss", 168, 0, [0, 3, 6, 7, 10, 12, 15], [0, 0, -2, 1], 4, lead_vol=0.15)
music("mtitle", 100, 0, [0, 3, 7, 10, 12, 14], [0, -4, -2, -7], 5, lead_vol=0.1, bass_wave="tri")

with open(os.path.join(OUT, "meta.json"), "w") as f:
    json.dump(META, f, indent=1)
print("assets ok:", len(os.listdir(OUT)))
